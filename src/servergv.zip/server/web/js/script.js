function hello() {
    alert("Hello world");
}
